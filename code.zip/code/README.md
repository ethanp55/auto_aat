Our code can be found in the "code" folder.  For the sake of storage space, we removed training data and model files, but the full git repository will be published upon acceptance of our paper.  The code in this anonymous repo should be sufficient for understanding how we implemented, trained, and tested the AATention network and the various bandit algorithms we explored.  The code is stored across three subfolders:
- jhg: train the AATention network only on JHG data
- chicken: train the AATention network only on repeated chicken game data
- jhg_chicken: train the AATention network on data from both the JHG and repeated chicken game

Within each of the above subfolders, there are subsubfolders:
- analysis: code for running statistical tests, generating graphs, etc.
- networks: code for the AATention network (and another network we originally experimented with but did not pursue further)
- train: code for training the AATention network
- utils: helper code
- forex: code for training and testing the various bandit algorithms in the forex market
- repeated_games: code for training and testing the various bandit algorithms in three different repeated games (prisoner's dilemma, chicken, and coordination)
- stag_hare: code for training and testing the various bandit algorithms in the Grid Stag Hung domain